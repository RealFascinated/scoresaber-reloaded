import {
	ATTR_DB_COLLECTION_NAME,
	ATTR_DB_OPERATION_NAME,
	createWithSpan,
} from "@better-auth/core/instrumentation";
import { createLogger, getColorDepth, TTY_COLORS } from "../../env";
import { BetterAuthError } from "../../error";
import type { BetterAuthOptions } from "../../types";
import { safeJSONParse } from "../../utils/json";
import { getAuthTables } from "../get-tables";
import { createAtomicFallbacks } from "./atomic-fallback";
import { initGetDefaultFieldName } from "./get-default-field-name";
import { initGetDefaultModelName } from "./get-default-model-name";
import { initGetFieldAttributes } from "./get-field-attributes";
import { initGetFieldName } from "./get-field-name";
import { initGetIdField } from "./get-id-field";
import { initGetModelName } from "./get-model-name";
import type {
	CleanedWhere,
	DBAdapter,
	DBTransactionAdapter,
	JoinConfig,
	JoinOption,
	Where,
} from "./index";
import type {
	AdapterFactoryConfig,
	AdapterFactoryOptions,
	AdapterTestDebugLogs,
} from "./types";
import { withApplyDefault } from "./utils";

export * from "./types";
export {
	initGetDefaultFieldName,
	initGetDefaultModelName,
	initGetFieldAttributes,
	initGetFieldName,
	initGetIdField,
	initGetModelName,
};

let debugLogs: { instance: string; args: any[] }[] = [];
let transactionId = -1;

const createAsIsTransaction =
	<Options extends BetterAuthOptions>(adapter: DBAdapter<Options>) =>
	<R>(fn: (trx: DBTransactionAdapter<Options>) => Promise<R>) =>
		fn(adapter);

export type AdapterFactory<Options extends BetterAuthOptions> = (
	options: Options,
) => DBAdapter<Options>;

export const createAdapterFactory =
	<Options extends BetterAuthOptions>({
		adapter: customAdapter,
		config: cfg,
	}: AdapterFactoryOptions): AdapterFactory<Options> =>
	(options: Options): DBAdapter<Options> => {
		const withSpan = createWithSpan(options);
		const uniqueAdapterFactoryInstanceId = Math.random()
			.toString(36)
			.substring(2, 15);

		const config = {
			...cfg,
			supportsBooleans: cfg.supportsBooleans ?? true,
			supportsDates: cfg.supportsDates ?? true,
			supportsJSON: cfg.supportsJSON ?? false,
			adapterName: cfg.adapterName ?? cfg.adapterId,
			supportsNumericIds: cfg.supportsNumericIds ?? true,
			supportsUUIDs: cfg.supportsUUIDs ?? false,
			supportsArrays: cfg.supportsArrays ?? false,
			transaction: cfg.transaction ?? false,
			disableTransformInput: cfg.disableTransformInput ?? false,
			disableTransformOutput: cfg.disableTransformOutput ?? false,
			disableTransformJoin: cfg.disableTransformJoin ?? false,
		} satisfies AdapterFactoryConfig;

		const useNumberId = options.advanced?.database?.generateId === "serial";
		if (useNumberId && config.supportsNumericIds === false) {
			throw new BetterAuthError(
				`[${config.adapterName}] Your database or database adapter does not support numeric ids. Please disable "useNumberId" in your config.`,
			);
		}

		// End-user's Better-Auth instance's schema
		const schema = getAuthTables(options);

		const debugLog = (...args: any[]) => {
			if (config.debugLogs === true || typeof config.debugLogs === "object") {
				const logger = createLogger({ level: "info" });
				// If we're running adapter tests, we'll keep debug logs in memory, then print them out if a test fails.
				if (
					typeof config.debugLogs === "object" &&
					"isRunningAdapterTests" in config.debugLogs
				) {
					if (config.debugLogs.isRunningAdapterTests) {
						args.shift(); // Removes the {method: "..."} object from the args array.
						debugLogs.push({ instance: uniqueAdapterFactoryInstanceId, args });
					}
					return;
				}

				if (
					typeof config.debugLogs === "object" &&
					config.debugLogs.logCondition &&
					!config.debugLogs.logCondition?.()
				) {
					return;
				}

				if (typeof args[0] === "object" && "method" in args[0]) {
					const method = args.shift().method;
					// Make sure the method is enabled in the config.
					if (typeof config.debugLogs === "object") {
						if (method === "create" && !config.debugLogs.create) {
							return;
						} else if (method === "update" && !config.debugLogs.update) {
							return;
						} else if (
							method === "updateMany" &&
							!config.debugLogs.updateMany
						) {
							return;
						} else if (method === "findOne" && !config.debugLogs.findOne) {
							return;
						} else if (method === "findMany" && !config.debugLogs.findMany) {
							return;
						} else if (method === "delete" && !config.debugLogs.delete) {
							return;
						} else if (
							method === "deleteMany" &&
							!config.debugLogs.deleteMany
						) {
							return;
						} else if (
							method === "consumeOne" &&
							!config.debugLogs.consumeOne
						) {
							return;
						} else if (
							method === "incrementOne" &&
							!config.debugLogs.incrementOne
						) {
							return;
						} else if (method === "count" && !config.debugLogs.count) {
							return;
						}
					}
					logger.info(`[${config.adapterName}]`, ...args);
				} else {
					logger.info(`[${config.adapterName}]`, ...args);
				}
			}
		};

		const logger = createLogger(options.logger);

		const getDefaultModelName = initGetDefaultModelName({
			usePlural: config.usePlural,
			schema,
		});

		const getDefaultFieldName = initGetDefaultFieldName({
			usePlural: config.usePlural,
			schema,
		});

		const getModelName = initGetModelName({
			usePlural: config.usePlural,
			schema,
		});
		const getFieldName = initGetFieldName({
			schema,
			usePlural: config.usePlural,
		});

		const idField = initGetIdField({
			schema,
			options,
			usePlural: config.usePlural,
			disableIdGeneration: config.disableIdGeneration,
			customIdGenerator: config.customIdGenerator,
			supportsUUIDs: config.supportsUUIDs,
		});

		const getFieldAttributes = initGetFieldAttributes({
			schema,
			options,
			usePlural: config.usePlural,
			disableIdGeneration: config.disableIdGeneration,
			customIdGenerator: config.customIdGenerator,
		});

		const transformInput = async (
			data: Record<string, any>,
			defaultModelName: string,
			action: "create" | "update" | "findOne" | "findMany",
			forceAllowId?: boolean,
		) => {
			const transformedData: Record<string, any> = {};
			const fields = schema[defaultModelName]!.fields;

			const newMappedKeys = config.mapKeysTransformInput ?? {};
			const useNumberId = options.advanced?.database?.generateId === "serial";
			fields.id = idField({
				customModelName: defaultModelName,
				forceAllowId: forceAllowId && "id" in data,
			});
			for (const field in fields) {
				let value = data[field];
				const fieldAttributes = fields[field];

				const newFieldName: string =
					newMappedKeys[field] || fields[field]!.fieldName || field;
				if (
					value === undefined &&
					((fieldAttributes!.defaultValue === undefined &&
						!fieldAttributes!.transform?.input &&
						!(action === "update" && fieldAttributes!.onUpdate)) ||
						(action === "update" && !fieldAttributes!.onUpdate))
				) {
					continue;
				}

				// In some endpoints (like signUpEmail) where there isn't proper Zod validation,
				// we might receive a date as a string (this is because of the client converting the Date to a string
				// when sending to the server). Because of this, we'll convert the string to a Date.
				if (
					fieldAttributes &&
					fieldAttributes.type === "date" &&
					!(value instanceof Date) &&
					typeof value === "string"
				) {
					try {
						value = new Date(value);
					} catch {
						logger.error("[Adapter Factory] Failed to convert string to date", {
							value,
							field,
						});
					}
				}

				// If the value is undefined, but the fieldAttr provides a `defaultValue`, then we'll use that.
				let newValue = withApplyDefault(value, fieldAttributes!, action);

				// If the field attr provides a custom transform input, then we'll let it handle the value transformation.
				// Afterwards, we'll continue to apply the default transformations just to make sure it saves in the correct format.
				if (fieldAttributes!.transform?.input) {
					newValue = await fieldAttributes!.transform.input(newValue);
				}

				if (fieldAttributes!.references?.field === "id" && useNumberId) {
					if (Array.isArray(newValue)) {
						newValue = newValue.map((x) => (x !== null ? Number(x) : null));
					} else {
						newValue = newValue !== null ? Number(newValue) : null;
					}
				} else if (
					config.supportsJSON === false &&
					typeof newValue === "object" &&
					fieldAttributes!.type === "json"
				) {
					newValue = JSON.stringify(newValue);
				} else if (
					config.supportsArrays === false &&
					Array.isArray(newValue) &&
					(fieldAttributes!.type === "string[]" ||
						fieldAttributes!.type === "number[]")
				) {
					newValue = JSON.stringify(newValue);
				} else if (
					config.supportsDates === false &&
					newValue instanceof Date &&
					fieldAttributes!.type === "date"
				) {
					newValue = newValue.toISOString();
				} else if (
					config.supportsBooleans === false &&
					typeof newValue === "boolean"
				) {
					newValue = newValue ? 1 : 0;
				}

				if (config.customTransformInput) {
					newValue = config.customTransformInput({
						data: newValue,
						action,
						field: newFieldName,
						fieldAttributes: fieldAttributes!,
						model: getModelName(defaultModelName),
						schema,
						options,
					});
				}

				if (newValue !== undefined) {
					transformedData[newFieldName] = newValue;
				}
			}
			return transformedData;
		};

		const transformOutput = async (
			data: Record<string, any> | null,
			inputModel: string,
			select: string[] = [],
			join: JoinConfig | undefined,
		) => {
			const transformSingleOutput = async (
				data: Record<string, any> | null,
				inputModel: string,
				select: string[] = [],
			) => {
				if (!data) return null;
				const modelKey = getDefaultModelName(inputModel);
				const newMappedKeys = config.mapKeysTransformOutput ?? {};
				const transformedData: Record<string, any> = {};
				const tableSchema = schema[modelKey]!.fields;
				const idKey = Object.entries(newMappedKeys).find(
					([_, v]) => v === "id",
				)?.[0];
				const useNumberId = options.advanced?.database?.generateId === "serial";
				tableSchema[idKey ?? "id"] = {
					type: useNumberId ? "number" : "string",
				};
				for (const key in tableSchema) {
					if (select.length && !select.includes(key)) {
						continue;
					}
					const field = tableSchema[key];
					if (field) {
						const originalKey = field.fieldName || key;

						// If the field is mapped, we'll use the mapped key. Otherwise, we'll use the original key.
						let newValue =
							data[
								Object.entries(newMappedKeys).find(
									([_, v]) => v === originalKey,
								)?.[0] || originalKey
							];

						if (field.transform?.output) {
							newValue = await field.transform.output(newValue);
						}

						const newFieldName: string = newMappedKeys[key] || key;

						if (originalKey === "id" || field.references?.field === "id") {
							// Even if `useNumberId` is true, we must always return a string `id` output.
							if (typeof newValue !== "undefined" && newValue !== null)
								newValue = String(newValue);
						} else if (
							config.supportsJSON === false &&
							typeof newValue === "string" &&
							field.type === "json"
						) {
							newValue = safeJSONParse(newValue);
						} else if (
							config.supportsArrays === false &&
							typeof newValue === "string" &&
							(field.type === "string[]" || field.type === "number[]")
						) {
							newValue = safeJSONParse(newValue);
						} else if (
							config.supportsDates === false &&
							typeof newValue === "string" &&
							field.type === "date"
						) {
							newValue = new Date(newValue);
						} else if (
							config.supportsBooleans === false &&
							typeof newValue === "number" &&
							field.type === "boolean"
						) {
							newValue = newValue === 1;
						}

						if (config.customTransformOutput) {
							newValue = config.customTransformOutput({
								data: newValue,
								field: newFieldName,
								fieldAttributes: field,
								select,
								model: getModelName(modelKey),
								schema,
								options,
							});
						}

						transformedData[newFieldName] = newValue;
					}
				}
				return transformedData as any;
			};

			if (!join || Object.keys(join).length === 0) {
				return await transformSingleOutput(data, inputModel, select);
			}

			const modelKey = getDefaultModelName(inputModel);
			// for now we just transform the base model
			// later we append the joined models to this object.
			const transformedData: Record<string, any> = await transformSingleOutput(
				data,
				modelKey,
				select,
			);

			// Get all the models that are required to be joined.
			const requiredModels = Object.entries(join).map(
				([model, joinConfig]) => ({
					modelName: model,
					defaultModelName: joinConfig.modelKey ?? getDefaultModelName(model),
					joinConfig,
				}),
			);

			if (!data) return null;
			// Data is now the base model object directly (not wrapped under a key)

			for (const {
				modelName,
				defaultModelName,
				joinConfig,
			} of requiredModels) {
				let joinedData = await (async () => {
					if (options.advanced?.database?.joins) {
						// Use native joined data when the adapter included the key;
						// otherwise fall back to separate queries.
						if (modelName in data) {
							return data[modelName];
						}
					}
					return await handleFallbackJoin({
						baseModel: modelKey,
						baseData: transformedData,
						joinModel: modelName,
						specificJoinConfig: joinConfig,
					});
				})();

				// If joinedData is undefined, initialize it based on relationship type
				if (joinedData === undefined || joinedData === null) {
					joinedData = joinConfig.relation === "one-to-one" ? null : [];
				}

				if (
					joinConfig.relation === "one-to-many" &&
					!Array.isArray(joinedData)
				) {
					joinedData = [joinedData];
				}

				const transformed = [];

				if (Array.isArray(joinedData)) {
					for (const item of joinedData) {
						const transformedItem = await transformSingleOutput(
							item,
							defaultModelName,
							[],
						);
						transformed.push(transformedItem);
					}
				} else {
					const transformedItem = await transformSingleOutput(
						joinedData,
						defaultModelName,
						[],
					);
					transformed.push(transformedItem);
				}

				const result =
					joinConfig.relation === "one-to-one" ? transformed[0] : transformed;
				transformedData[defaultModelName] = result ?? null;
			}

			return transformedData as any;
		};

		const transformWhereClause = <W extends Where[] | undefined>({
			model,
			where,
			action,
		}: {
			where: W;
			model: string;
			action:
				| "create"
				| "update"
				| "findOne"
				| "findMany"
				| "updateMany"
				| "delete"
				| "deleteMany"
				| "consumeOne"
				| "incrementOne"
				| "count";
		}): W extends undefined ? undefined : CleanedWhere[] => {
			if (!where) return undefined as any;
			const newMappedKeys = config.mapKeysTransformInput ?? {};

			return where.map((w) => {
				const {
					field: unsafe_field,
					value,
					operator = "eq",
					connector = "AND",
					mode = "sensitive",
				} = w;
				if (operator === "in") {
					if (!Array.isArray(value)) {
						throw new BetterAuthError("Value must be an array");
					}
				}

				let newValue = value;

				const defaultModelName = getDefaultModelName(model);
				const defaultFieldName = getDefaultFieldName({
					field: unsafe_field,
					model,
				});
				const fieldName: string =
					newMappedKeys[defaultFieldName] ||
					getFieldName({
						field: defaultFieldName,
						model: defaultModelName,
					});

				const fieldAttr = getFieldAttributes({
					field: defaultFieldName,
					model: defaultModelName,
				});

				const useNumberId = options.advanced?.database?.generateId === "serial";

				if (
					defaultFieldName === "id" ||
					fieldAttr!.references?.field === "id"
				) {
					if (useNumberId) {
						if (Array.isArray(value)) {
							newValue = value.map(Number);
						} else {
							newValue = Number(value);
						}
					}
				}

				if (
					fieldAttr.type === "date" &&
					value instanceof Date &&
					!config.supportsDates
				) {
					newValue = value.toISOString();
				}

				if (fieldAttr.type === "boolean" && typeof newValue === "string") {
					newValue = newValue === "true";
				}

				if (fieldAttr.type === "number") {
					if (typeof newValue === "string" && newValue.trim() !== "") {
						const parsed = Number(newValue);
						if (!Number.isNaN(parsed)) {
							newValue = parsed;
						}
					} else if (Array.isArray(newValue)) {
						const parsed = newValue.map((v) =>
							typeof v === "string" && v.trim() !== "" ? Number(v) : NaN,
						);
						if (parsed.every((n) => !Number.isNaN(n))) {
							newValue = parsed;
						}
					}
				}

				if (
					fieldAttr.type === "boolean" &&
					typeof newValue === "boolean" &&
					!config.supportsBooleans
				) {
					newValue = newValue ? 1 : 0;
				}

				if (
					fieldAttr.type === "json" &&
					typeof value === "object" &&
					!config.supportsJSON
				) {
					try {
						const stringifiedJSON = JSON.stringify(value);
						newValue = stringifiedJSON;
					} catch (error) {
						throw new Error(
							`Failed to stringify JSON value for field ${fieldName}`,
							{ cause: error },
						);
					}
				}

				if (config.customTransformInput) {
					newValue = config.customTransformInput({
						data: newValue,
						fieldAttributes: fieldAttr,
						field: fieldName,
						model: getModelName(model),
						schema,
						options,
						action,
					});
				}

				return {
					operator,
					connector,
					field: fieldName,
					value: newValue,
					mode,
				} satisfies CleanedWhere;
			}) as any;
		};

		const transformJoinClause = (
			baseModel: string,
			unsanitizedJoin: JoinOption | undefined,
			select: string[] | undefined,
		): { join: JoinConfig; select: string[] | undefined } | undefined => {
			if (!unsanitizedJoin) return undefined;
			if (Object.keys(unsanitizedJoin).length === 0) return undefined;
			const transformedJoin: JoinConfig = {};
			for (const [model, join] of Object.entries(unsanitizedJoin)) {
				if (!join) continue;
				const defaultModelName = getDefaultModelName(model);
				const defaultBaseModelName = getDefaultModelName(baseModel);

				// First, check if the joined model has FKs to the base model (forward join)
				let foreignKeys = Object.entries(
					schema[defaultModelName]!.fields,
				).filter(
					([field, fieldAttributes]) =>
						fieldAttributes.references &&
						getDefaultModelName(fieldAttributes.references.model) ===
							defaultBaseModelName,
				);

				let isForwardJoin = true;

				// If no forward join found, check backwards: does the base model have FKs to the joined model?
				if (!foreignKeys.length) {
					foreignKeys = Object.entries(
						schema[defaultBaseModelName]!.fields,
					).filter(
						([field, fieldAttributes]) =>
							fieldAttributes.references &&
							getDefaultModelName(fieldAttributes.references.model) ===
								defaultModelName,
					);
					isForwardJoin = false;
				}

				if (!foreignKeys.length) {
					throw new BetterAuthError(
						`No foreign key found for model ${model} and base model ${baseModel} while performing join operation.`,
					);
				} else if (foreignKeys.length > 1) {
					throw new BetterAuthError(
						`Multiple foreign keys found for model ${model} and base model ${baseModel} while performing join operation. Only one foreign key is supported.`,
					);
				}

				const [foreignKey, foreignKeyAttributes] = foreignKeys[0]!;
				if (!foreignKeyAttributes.references) {
					// this should never happen, as we filter for references in the foreign keys.
					// it's here for typescript to be happy.
					throw new BetterAuthError(
						`No references found for foreign key ${foreignKey} on model ${model} while performing join operation.`,
					);
				}

				let from: string;
				let to: string;
				let requiredSelectField: string;

				if (isForwardJoin) {
					// joined model has FK to base model
					// The field we need in select is the referenced field in the base model
					requiredSelectField = foreignKeyAttributes.references.field;
					from = getFieldName({
						model: baseModel,
						field: requiredSelectField,
					});

					to = getFieldName({
						model,
						field: foreignKey,
					});
				} else {
					// base model has FK to joined model
					// The field we need in select is the foreign key field in the base model
					requiredSelectField = foreignKey;
					from = getFieldName({
						model: baseModel,
						field: requiredSelectField,
					});

					to = getFieldName({
						model,
						field: foreignKeyAttributes.references.field,
					});
				}

				// Ensure the required field is in select if select is provided
				if (select && !select.includes(requiredSelectField)) {
					select.push(requiredSelectField);
				}

				const isUnique =
					to === "id" ? true : (foreignKeyAttributes.unique ?? false);

				let limit: number =
					options.advanced?.database?.defaultFindManyLimit ?? 100;
				if (isUnique) {
					limit = 1;
				} else if (typeof join === "object" && typeof join.limit === "number") {
					limit = join.limit;
				}

				transformedJoin[getModelName(model)] = {
					modelKey: model,
					on: {
						from,
						to,
					},
					limit,
					relation: isUnique ? "one-to-one" : "one-to-many",
				};
			}
			return { join: transformedJoin, select };
		};

		/**
		 * Handle joins by making separate queries and combining results (fallback for adapters that don't support native joins).
		 */
		const handleFallbackJoin = async <T extends Record<string, any> | null>({
			baseModel,
			baseData,
			joinModel,
			specificJoinConfig: joinConfig,
		}: {
			baseModel: string;
			baseData: T;
			joinModel: string;
			specificJoinConfig: JoinConfig[number];
		}) => {
			if (!baseData) return baseData;
			const modelKey = joinConfig.modelKey ?? getDefaultModelName(joinModel);
			const modelName = getModelName(modelKey);
			const field = joinConfig.on.to;
			const value =
				baseData[
					getDefaultFieldName({ field: joinConfig.on.from, model: baseModel })
				];

			if (value === null || value === undefined) {
				// If there is no value, it could mean that the query used a `select` clause that didn't include the field.
				// or the query result is purely empty.
				// In any case, we return null/empty array.
				return joinConfig.relation === "one-to-one" ? null : [];
			}
			let result: Record<string, any> | Record<string, any>[] | null;
			const where = transformWhereClause({
				model: modelKey,
				where: [
					{
						field,
						value,
						operator: "eq",
						connector: "AND",
					},
				],
				action: "findOne",
			});
			try {
				if (joinConfig.relation === "one-to-one") {
					result = await withSpan(
						`db findOne ${modelName}`,
						{
							[ATTR_DB_OPERATION_NAME]: "findOne",
							[ATTR_DB_COLLECTION_NAME]: modelName,
						},
						() =>
							adapterInstance.findOne<Record<string, any>>({
								model: modelName,
								modelKey,
								where: where,
							}),
					);
				} else {
					const limit =
						joinConfig.limit ??
						options.advanced?.database?.defaultFindManyLimit ??
						100;
					result = await withSpan(
						`db findMany ${modelName}`,
						{
							[ATTR_DB_OPERATION_NAME]: "findMany",
							[ATTR_DB_COLLECTION_NAME]: modelName,
						},
						() =>
							adapterInstance.findMany<Record<string, any>>({
								model: modelName,
								modelKey,
								where: where,
								limit,
							}),
					);
				}
			} catch (error) {
				logger.error(`Failed to query fallback join for model ${modelName}:`, {
					where,
					limit: joinConfig.limit,
				});
				console.error(error);
				throw error;
			}
			return result;
		};

		const adapterInstance = customAdapter({
			options,
			schema,
			debugLog,
			getFieldName,
			getModelName,
			getDefaultModelName,
			getDefaultFieldName,
			getFieldAttributes,
			transformInput,
			transformOutput,
			transformWhereClause,
		});

		let lazyLoadTransaction: DBAdapter<Options>["transaction"] | null = null;
		const atomicFallbacks = createAtomicFallbacks({
			adapter: adapterInstance,
			adapterId: config.adapterId,
			mapKeysTransformInput: config.mapKeysTransformInput,
			mapKeysTransformOutput: config.mapKeysTransformOutput,
			getFieldName,
			transformOutput,
			transformWhereClause,
		});

		const adapter: DBAdapter<Options> = {
			transaction: async (cb) => {
				if (!lazyLoadTransaction) {
					if (!config.transaction) {
						lazyLoadTransaction = createAsIsTransaction(adapter);
					} else {
						logger.debug(
							`[${config.adapterName}] - Using provided transaction implementation.`,
						);
						lazyLoadTransaction = config.transaction;
					}
				}
				return lazyLoadTransaction(cb);
			},
			create: async <T extends Record<string, any>, R = T>({
				data: unsafeData,
				model: inputModel,
				select,
				forceAllowId = false,
			}: {
				model: string;
				data: T;
				select?: string[] | undefined;
				forceAllowId?: boolean | undefined;
			}): Promise<R> => {
				transactionId++;
				const thisTransactionId = transactionId;
				const modelKey = getDefaultModelName(inputModel);
				const model = getModelName(modelKey);
				if (
					"id" in unsafeData &&
					typeof unsafeData.id !== "undefined" &&
					!forceAllowId
				) {
					// The reason why `forceAllowId` was introduced was because we used to handle
					// id generation ourselves (eg adapter.create({ data: { id: "123" } }))
					// This was bad as certain things (such as number ids) would not work as expected.
					// Since then, we have introduced the `forceAllowId` parameter to allow users to
					// bypass this check. Otherwise, we would throw a warning stating that the id will be ignored
					logger.warn(
						`[${config.adapterName}] - You are trying to create a record with an id. This is not allowed as we handle id generation for you, unless you pass in the \`forceAllowId\` parameter. The id will be ignored.`,
					);
					const err = new Error();
					const stack = err.stack
						?.split("\n")
						.filter((_, i) => i !== 1)
						.join("\n")
						.replace("Error:", "Create method with `id` being called at:");
					console.log(stack);
					//@ts-expect-error
					unsafeData.id = undefined;
				}
				debugLog(
					{ method: "create" },
					`${formatTransactionId(thisTransactionId)} ${formatStep(1, 4)}`,
					`${formatMethod("create")} ${formatAction("Unsafe Input")}:`,
					{ model, data: unsafeData },
				);
				let data = unsafeData;
				if (!config.disableTransformInput) {
					data = (await transformInput(
						unsafeData,
						modelKey,
						"create",
						forceAllowId,
					)) as T;
				}
				debugLog(
					{ method: "create" },
					`${formatTransactionId(thisTransactionId)} ${formatStep(2, 4)}`,
					`${formatMethod("create")} ${formatAction("Parsed Input")}:`,
					{ model, data },
				);
				const res = await withSpan(
					`db create ${model}`,
					{
						[ATTR_DB_OPERATION_NAME]: "create",
						[ATTR_DB_COLLECTION_NAME]: model,
					},
					() =>
						adapterInstance.create<T>({
							data,
							model,
							modelKey,
						}),
				);
				debugLog(
					{ method: "create" },
					`${formatTransactionId(thisTransactionId)} ${formatStep(3, 4)}`,
					`${formatMethod("create")} ${formatAction("DB Result")}:`,
					{ model, res },
				);
				let transformed = res as any;
				if (!config.disableTransformOutput) {
					transformed = await transformOutput(
						res as any,
						modelKey,
						select,
						undefined,
					);
				}
				debugLog(
					{ method: "create" },
					`${formatTransactionId(thisTransactionId)} ${formatStep(4, 4)}`,
					`${formatMethod("create")} ${formatAction("Parsed Result")}:`,
					{ model, data: transformed },
				);
				return transformed;
			},
			update: async <T>({
				model: inputModel,
				where: unsafeWhere,
				update: unsafeData,
			}: {
				model: string;
				where: Where[];
				update: Record<string, any>;
			}): Promise<T | null> => {
				transactionId++;
				const thisTransactionId = transactionId;
				const modelKey = getDefaultModelName(inputModel);
				const model = getModelName(modelKey);
				const where = transformWhereClause({
					model: modelKey,
					where: unsafeWhere,
					action: "update",
				});
				// `update` targets a single row. Empty predicates have no
				// target, so fail closed and leave bulk writes to `updateMany`.
				if (where.length === 0) {
					return null;
				}
				debugLog(
					{ method: "update" },
					`${formatTransactionId(thisTransactionId)} ${formatStep(1, 4)}`,
					`${formatMethod("update")} ${formatAction("Unsafe Input")}:`,
					{ model, data: unsafeData },
				);
				let data = unsafeData as T;
				if (!config.disableTransformInput) {
					data = (await transformInput(unsafeData, modelKey, "update")) as T;
				}
				debugLog(
					{ method: "update" },
					`${formatTransactionId(thisTransactionId)} ${formatStep(2, 4)}`,
					`${formatMethod("update")} ${formatAction("Parsed Input")}:`,
					{ model, data },
				);
				const res = await withSpan(
					`db update ${model}`,
					{
						[ATTR_DB_OPERATION_NAME]: "update",
						[ATTR_DB_COLLECTION_NAME]: model,
					},
					() =>
						adapterInstance.update<T>({
							model,
							modelKey,
							where,
							update: data,
						}),
				);
				debugLog(
					{ method: "update" },
					`${formatTransactionId(thisTransactionId)} ${formatStep(3, 4)}`,
					`${formatMethod("update")} ${formatAction("DB Result")}:`,
					{ model, data: res },
				);
				let transformed = res as any;
				if (!config.disableTransformOutput) {
					transformed = await transformOutput(
						res as any,
						modelKey,
						undefined,
						undefined,
					);
				}
				debugLog(
					{ method: "update" },
					`${formatTransactionId(thisTransactionId)} ${formatStep(4, 4)}`,
					`${formatMethod("update")} ${formatAction("Parsed Result")}:`,
					{ model, data: transformed },
				);
				return transformed;
			},
			updateMany: async ({
				model: inputModel,
				where: unsafeWhere,
				update: unsafeData,
			}: {
				model: string;
				where: Where[];
				update: Record<string, any>;
			}) => {
				transactionId++;
				const thisTransactionId = transactionId;
				const modelKey = getDefaultModelName(inputModel);
				const model = getModelName(modelKey);
				const where = transformWhereClause({
					model: modelKey,
					where: unsafeWhere,
					action: "updateMany",
				});
				debugLog(
					{ method: "updateMany" },
					`${formatTransactionId(thisTransactionId)} ${formatStep(1, 4)}`,
					`${formatMethod("updateMany")} ${formatAction("Unsafe Input")}:`,
					{ model, data: unsafeData },
				);
				let data = unsafeData;
				if (!config.disableTransformInput) {
					data = await transformInput(unsafeData, modelKey, "update");
				}
				debugLog(
					{ method: "updateMany" },
					`${formatTransactionId(thisTransactionId)} ${formatStep(2, 4)}`,
					`${formatMethod("updateMany")} ${formatAction("Parsed Input")}:`,
					{ model, data },
				);

				const updatedCount = await withSpan(
					`db updateMany ${model}`,
					{
						[ATTR_DB_OPERATION_NAME]: "updateMany",
						[ATTR_DB_COLLECTION_NAME]: model,
					},
					() =>
						adapterInstance.updateMany({
							model,
							modelKey,
							where,
							update: data,
						}),
				);
				if (
					typeof updatedCount !== "number" ||
					!Number.isFinite(updatedCount)
				) {
					throw new BetterAuthError(
						`Adapter "${config.adapterId}" updateMany must return a finite number affected row count.`,
					);
				}
				debugLog(
					{ method: "updateMany" },
					`${formatTransactionId(thisTransactionId)} ${formatStep(3, 4)}`,
					`${formatMethod("updateMany")} ${formatAction("DB Result")}:`,
					{ model, data: updatedCount },
				);
				debugLog(
					{ method: "updateMany" },
					`${formatTransactionId(thisTransactionId)} ${formatStep(4, 4)}`,
					`${formatMethod("updateMany")} ${formatAction("Parsed Result")}:`,
					{ model, data: updatedCount },
				);
				return updatedCount;
			},
			findOne: async <T extends Record<string, any>>({
				model: inputModel,
				where: unsafeWhere,
				select,
				join: unsafeJoin,
			}: {
				model: string;
				where: Where[];
				select?: string[] | undefined;
				join?: JoinOption | undefined;
			}) => {
				transactionId++;
				const thisTransactionId = transactionId;
				const modelKey = getDefaultModelName(inputModel);
				const model = getModelName(modelKey);
				const where = transformWhereClause({
					model: modelKey,
					where: unsafeWhere,
					action: "findOne",
				});
				let join: JoinConfig | undefined;
				let passJoinToAdapter = true;
				if (!config.disableTransformJoin) {
					const result = transformJoinClause(modelKey, unsafeJoin, select);
					if (result) {
						join = result.join;
						select = result.select;
					}
					// If joins are disabled and we have joins, don't pass them to the adapter
					if (
						!options.advanced?.database?.joins &&
						join &&
						Object.keys(join).length > 0
					) {
						passJoinToAdapter = false;
					}
				} else {
					// assume it's already transformed if transformation is disabled
					join = unsafeJoin as never as JoinConfig;
				}
				debugLog(
					{ method: "findOne" },
					`${formatTransactionId(thisTransactionId)} ${formatStep(1, 3)}`,
					`${formatMethod("findOne")}:`,
					{ model, where, select, join },
				);

				const res = await withSpan(
					`db findOne ${model}`,
					{
						[ATTR_DB_OPERATION_NAME]: "findOne",
						[ATTR_DB_COLLECTION_NAME]: model,
					},
					() =>
						adapterInstance.findOne<T>({
							model,
							modelKey,
							where,
							select,
							join: passJoinToAdapter ? join : undefined,
						}),
				);
				debugLog(
					{ method: "findOne" },
					`${formatTransactionId(thisTransactionId)} ${formatStep(2, 3)}`,
					`${formatMethod("findOne")} ${formatAction("DB Result")}:`,
					{ model, data: res },
				);

				// Handle fallback join if adapter doesn't support joins
				let transformed = res as any;
				if (!config.disableTransformOutput) {
					transformed = await transformOutput(res, modelKey, select, join);
				}
				debugLog(
					{ method: "findOne" },
					`${formatTransactionId(thisTransactionId)} ${formatStep(3, 3)}`,
					`${formatMethod("findOne")} ${formatAction("Parsed Result")}:`,
					{ model, data: transformed },
				);
				return transformed;
			},
			findMany: async <T extends Record<string, any>>({
				model: inputModel,
				where: unsafeWhere,
				limit: unsafeLimit,
				select,
				sortBy,
				offset,
				join: unsafeJoin,
			}: {
				model: string;
				where?: Where[] | undefined;
				limit?: number | undefined;
				select?: string[] | undefined;
				sortBy?: { field: string; direction: "asc" | "desc" } | undefined;
				offset?: number | undefined;
				join?: JoinOption | undefined;
			}) => {
				transactionId++;
				const thisTransactionId = transactionId;
				const limit =
					unsafeLimit ??
					options.advanced?.database?.defaultFindManyLimit ??
					100;
				const modelKey = getDefaultModelName(inputModel);
				const model = getModelName(modelKey);
				const where = transformWhereClause({
					model: modelKey,
					where: unsafeWhere,
					action: "findMany",
				});
				let join: JoinConfig | undefined;
				let passJoinToAdapter = true;
				if (!config.disableTransformJoin) {
					const result = transformJoinClause(modelKey, unsafeJoin, select);
					if (result) {
						join = result.join;
						select = result.select;
					}
					// If joins are disabled and we have joins, don't pass them to the adapter
					if (
						!options.advanced?.database?.joins &&
						join &&
						Object.keys(join).length > 0
					) {
						passJoinToAdapter = false;
					}
				} else {
					// assume it's already transformed if transformation is disabled
					join = unsafeJoin as never as JoinConfig;
				}
				debugLog(
					{ method: "findMany" },
					`${formatTransactionId(thisTransactionId)} ${formatStep(1, 3)}`,
					`${formatMethod("findMany")}:`,
					{ model, where, limit, sortBy, offset, join },
				);
				const res = await withSpan(
					`db findMany ${model}`,
					{
						[ATTR_DB_OPERATION_NAME]: "findMany",
						[ATTR_DB_COLLECTION_NAME]: model,
					},
					() =>
						adapterInstance.findMany<T>({
							model,
							modelKey,
							where,
							limit: limit,
							select,
							sortBy,
							offset,
							join: passJoinToAdapter ? join : undefined,
						}),
				);
				debugLog(
					{ method: "findMany" },
					`${formatTransactionId(thisTransactionId)} ${formatStep(2, 3)}`,
					`${formatMethod("findMany")} ${formatAction("DB Result")}:`,
					{ model, data: res },
				);

				let transformed = res as any;
				if (!config.disableTransformOutput) {
					transformed = await Promise.all(
						res.map(async (r: Record<string, any>) => {
							return await transformOutput(r, modelKey, undefined, join);
						}),
					);
				}

				debugLog(
					{ method: "findMany" },
					`${formatTransactionId(thisTransactionId)} ${formatStep(3, 3)}`,
					`${formatMethod("findMany")} ${formatAction("Parsed Result")}:`,
					{ model, data: transformed },
				);
				return transformed;
			},
			delete: async ({
				model: inputModel,
				where: unsafeWhere,
			}: {
				model: string;
				where: Where[];
			}) => {
				transactionId++;
				const thisTransactionId = transactionId;
				const modelKey = getDefaultModelName(inputModel);
				const model = getModelName(modelKey);
				const where = transformWhereClause({
					model: modelKey,
					where: unsafeWhere,
					action: "delete",
				});
				debugLog(
					{ method: "delete" },
					`${formatTransactionId(thisTransactionId)} ${formatStep(1, 2)}`,
					`${formatMethod("delete")}:`,
					{ model, where },
				);
				await withSpan(
					`db delete ${model}`,
					{
						[ATTR_DB_OPERATION_NAME]: "delete",
						[ATTR_DB_COLLECTION_NAME]: model,
					},
					() =>
						adapterInstance.delete({
							model,
							modelKey,
							where,
						}),
				);
				debugLog(
					{ method: "delete" },
					`${formatTransactionId(thisTransactionId)} ${formatStep(2, 2)}`,
					`${formatMethod("delete")} ${formatAction("DB Result")}:`,
					{ model },
				);
			},
			deleteMany: async ({
				model: inputModel,
				where: unsafeWhere,
			}: {
				model: string;
				where: Where[];
			}) => {
				transactionId++;
				const thisTransactionId = transactionId;
				const modelKey = getDefaultModelName(inputModel);
				const model = getModelName(modelKey);
				const where = transformWhereClause({
					model: modelKey,
					where: unsafeWhere,
					action: "deleteMany",
				});
				debugLog(
					{ method: "deleteMany" },
					`${formatTransactionId(thisTransactionId)} ${formatStep(1, 2)}`,
					`${formatMethod("deleteMany")} ${formatAction("DeleteMany")}:`,
					{ model, where },
				);
				const res = await withSpan(
					`db deleteMany ${model}`,
					{
						[ATTR_DB_OPERATION_NAME]: "deleteMany",
						[ATTR_DB_COLLECTION_NAME]: model,
					},
					() =>
						adapterInstance.deleteMany({
							model,
							modelKey,
							where,
						}),
				);
				debugLog(
					{ method: "deleteMany" },
					`${formatTransactionId(thisTransactionId)} ${formatStep(2, 2)}`,
					`${formatMethod("deleteMany")} ${formatAction("DB Result")}:`,
					{ model, data: res },
				);
				return res;
			},
			consumeOne: async <T>({
				model: inputModel,
				where: unsafeWhere,
			}: {
				model: string;
				where: Where[];
			}): Promise<T | null> => {
				transactionId++;
				const thisTransactionId = transactionId;
				const modelKey = getDefaultModelName(inputModel);
				const model = getModelName(modelKey);
				const where = transformWhereClause({
					model: modelKey,
					where: unsafeWhere,
					action: "consumeOne",
				});
				debugLog(
					{ method: "consumeOne" },
					`${formatTransactionId(thisTransactionId)} ${formatStep(1, 3)}`,
					`${formatMethod("consumeOne")} ${formatAction("ConsumeOne")}:`,
					{ model, where },
				);

				const res = await withSpan(
					`db consumeOne ${model}`,
					{
						[ATTR_DB_OPERATION_NAME]: "consumeOne",
						[ATTR_DB_COLLECTION_NAME]: model,
					},
					() =>
						adapterInstance.consumeOne
							? adapterInstance.consumeOne<T>({
									model,
									modelKey,
									where,
								})
							: atomicFallbacks.consumeOne({
									model,
									modelKey,
									where,
								}),
				);

				debugLog(
					{ method: "consumeOne" },
					`${formatTransactionId(thisTransactionId)} ${formatStep(2, 3)}`,
					`${formatMethod("consumeOne")} ${formatAction("DB Result")}:`,
					{ model, data: res },
				);
				let transformed: any = res;
				if (!config.disableTransformOutput && res) {
					transformed = await transformOutput(
						res as Record<string, any>,
						modelKey,
						undefined,
						undefined,
					);
				}
				debugLog(
					{ method: "consumeOne" },
					`${formatTransactionId(thisTransactionId)} ${formatStep(3, 3)}`,
					`${formatMethod("consumeOne")} ${formatAction("Parsed Result")}:`,
					{ model, data: transformed },
				);
				return transformed as T | null;
			},
			incrementOne: async <T>({
				model: inputModel,
				where: unsafeWhere,
				increment: unsafeIncrement,
				set: unsafeSet,
			}: {
				model: string;
				where: Where[];
				increment: Record<string, number>;
				set?: Record<string, unknown> | undefined;
			}): Promise<T | null> => {
				const hasIncrement = Object.keys(unsafeIncrement).length > 0;
				const hasSet = !!unsafeSet && Object.keys(unsafeSet).length > 0;
				if (!hasIncrement && !hasSet) {
					// An empty `increment` and empty `set` compiles to `UPDATE ... SET `
					// with no assignments, which is a syntax error on kysely, drizzle, and
					// Prisma. Fail fast with an actionable message instead.
					throw new BetterAuthError(
						"incrementOne requires a non-empty `increment` or `set`; both were empty.",
					);
				}
				transactionId++;
				const thisTransactionId = transactionId;
				const modelKey = getDefaultModelName(inputModel);
				const model = getModelName(modelKey);
				const where = transformWhereClause({
					model: modelKey,
					where: unsafeWhere,
					action: "incrementOne",
				});
				debugLog(
					{ method: "incrementOne" },
					`${formatTransactionId(thisTransactionId)} ${formatStep(1, 3)}`,
					`${formatMethod("incrementOne")} ${formatAction("IncrementOne")}:`,
					{ model, where, increment: unsafeIncrement, set: unsafeSet },
				);

				const mappedKeys = config.mapKeysTransformInput ?? {};
				const increment: Record<string, number> = {};
				for (const [field, delta] of Object.entries(unsafeIncrement)) {
					increment[
						mappedKeys[field] || getFieldName({ model: modelKey, field })
					] = delta;
				}
				let set: Record<string, unknown> | undefined;
				if (unsafeSet && !config.disableTransformInput) {
					set = await transformInput(unsafeSet, modelKey, "update");
				} else {
					set = unsafeSet;
				}
				if (
					Object.keys(increment).length === 0 &&
					(!set || Object.keys(set).length === 0)
				) {
					throw new BetterAuthError(
						"incrementOne resolved to an empty update: every increment/set field was unknown to the schema or transformed away.",
					);
				}
				const res = await withSpan(
					`db incrementOne ${model}`,
					{
						[ATTR_DB_OPERATION_NAME]: "incrementOne",
						[ATTR_DB_COLLECTION_NAME]: model,
					},
					() =>
						adapterInstance.incrementOne
							? adapterInstance.incrementOne<T>({
									model,
									modelKey,
									where,
									increment,
									set,
								})
							: atomicFallbacks.incrementOne({
									model,
									modelKey,
									where,
									increment,
									set,
								}),
				);

				debugLog(
					{ method: "incrementOne" },
					`${formatTransactionId(thisTransactionId)} ${formatStep(2, 3)}`,
					`${formatMethod("incrementOne")} ${formatAction("DB Result")}:`,
					{ model, data: res },
				);
				let transformed: any = res;
				if (!config.disableTransformOutput && res) {
					transformed = await transformOutput(
						res as Record<string, any>,
						modelKey,
						undefined,
						undefined,
					);
				}
				debugLog(
					{ method: "incrementOne" },
					`${formatTransactionId(thisTransactionId)} ${formatStep(3, 3)}`,
					`${formatMethod("incrementOne")} ${formatAction("Parsed Result")}:`,
					{ model, data: transformed },
				);
				return transformed as T | null;
			},
			count: async ({
				model: inputModel,
				where: unsafeWhere,
			}: {
				model: string;
				where?: Where[] | undefined;
			}) => {
				transactionId++;
				const thisTransactionId = transactionId;
				const modelKey = getDefaultModelName(inputModel);
				const model = getModelName(modelKey);
				const where = transformWhereClause({
					model: modelKey,
					where: unsafeWhere,
					action: "count",
				});
				debugLog(
					{ method: "count" },
					`${formatTransactionId(thisTransactionId)} ${formatStep(1, 2)}`,
					`${formatMethod("count")}:`,
					{
						model,
						where,
					},
				);
				const res = await withSpan(
					`db count ${model}`,
					{
						[ATTR_DB_OPERATION_NAME]: "count",
						[ATTR_DB_COLLECTION_NAME]: model,
					},
					() =>
						adapterInstance.count({
							model,
							modelKey,
							where,
						}),
				);
				debugLog(
					{ method: "count" },
					`${formatTransactionId(thisTransactionId)} ${formatStep(2, 2)}`,
					`${formatMethod("count")}:`,
					{
						model,
						data: res,
					},
				);
				return res;
			},
			createSchema: adapterInstance.createSchema
				? async (_, file) => {
						const tables = getAuthTables(options);

						if (
							options.secondaryStorage &&
							!options.session?.storeSessionInDatabase
						) {
							// biome-ignore lint/performance/noDelete: If the user has enabled secondaryStorage, as well as not specifying to store session table in DB, then createSchema shouldn't generate schema table.
							delete tables.session;
						}

						return adapterInstance.createSchema!({ file, tables });
					}
				: undefined,
			options: {
				adapterConfig: config,
				...(adapterInstance.options ?? {}),
			},
			id: config.adapterId,

			// Secretly export values ONLY if this adapter has enabled adapter-test-debug-logs.
			// This would then be used during our adapter-tests to help print debug logs if a test fails.
			//@ts-expect-error - ^^
			...(config.debugLogs?.isRunningAdapterTests
				? {
						adapterTestDebugLogs: {
							resetDebugLogs() {
								debugLogs = debugLogs.filter(
									(log) => log.instance !== uniqueAdapterFactoryInstanceId,
								);
							},
							printDebugLogs() {
								const separator = `─`.repeat(80);
								const logs = debugLogs.filter(
									(log) => log.instance === uniqueAdapterFactoryInstanceId,
								);
								if (logs.length === 0) {
									return;
								}

								//`${colors.fg.blue}|${colors.reset} `,
								const log: any[] = logs
									.reverse()
									.map((log) => {
										log.args[0] = `\n${log.args[0]}`;
										return [...log.args, "\n"];
									})
									.reduce(
										(prev, curr) => {
											return [...curr, ...prev];
										},
										[`\n${separator}`],
									);

								console.log(...log);
							},
						} satisfies AdapterTestDebugLogs,
					}
				: {}),
		};
		return adapter;
	};

function formatTransactionId(transactionId: number) {
	if (getColorDepth() < 8) {
		return `#${transactionId}`;
	}
	return `${TTY_COLORS.fg.magenta}#${transactionId}${TTY_COLORS.reset}`;
}

function formatStep(step: number, total: number) {
	return `${TTY_COLORS.bg.black}${TTY_COLORS.fg.yellow}[${step}/${total}]${TTY_COLORS.reset}`;
}

function formatMethod(method: string) {
	return `${TTY_COLORS.bright}${method}${TTY_COLORS.reset}`;
}

function formatAction(action: string) {
	return `${TTY_COLORS.dim}(${action})${TTY_COLORS.reset}`;
}
