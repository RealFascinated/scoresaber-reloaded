import { betterFetch } from "@better-fetch/fetch";
import type { JWTPayload } from "jose";
import { decodeJwt, decodeProtectedHeader, importJWK, jwtVerify } from "jose";
import { logger } from "../env";
import { APIError, BetterAuthError } from "../error";
import type { OAuthProvider, ProviderOptions } from "../oauth2";
import {
	createAuthorizationURL,
	getPrimaryClientId,
	refreshAccessToken,
	validateAuthorizationCode,
} from "../oauth2";

export interface GoogleProfile {
	aud: string;
	azp: string;
	email: string;
	email_verified: boolean;
	exp: number;
	/**
	 * The family name of the user, or last name in most
	 * Western languages.
	 */
	family_name: string;
	/**
	 * The given name of the user, or first name in most
	 * Western languages.
	 */
	given_name: string;
	hd?: string | undefined;
	iat: number;
	iss: string;
	jti?: string | undefined;
	locale?: string | undefined;
	name: string;
	nbf?: number | undefined;
	picture: string;
	sub: string;
}

export interface GoogleOptions extends ProviderOptions<GoogleProfile> {
	clientId: string | string[];
	/**
	 * The access type to use for the authorization code request
	 */
	accessType?: ("offline" | "online") | undefined;
	/**
	 * The display mode to use for the authorization code request
	 */
	display?: ("page" | "popup" | "touch" | "wap") | undefined;
	/**
	 * The hosted domain (Google Workspace) the user must belong to.
	 *
	 * This is sent to Google as the `hd` authorization hint and, when set, is
	 * also enforced against the `hd` claim of the returned id token/profile.
	 * Set `hd: "*"` to require any Workspace hosted-domain claim. Sign-in is
	 * rejected when the claim is missing or does not satisfy this restriction.
	 */
	hd?: string | undefined;
	/**
	 * Whether to send `include_granted_scopes=true` to Google's authorization
	 * endpoint, which lets new access tokens cover scopes from prior grants
	 * in addition to the ones requested for this flow. Set to `false` when
	 * each OAuth flow should request only its own scopes.
	 *
	 * Defaults to `true`.
	 *
	 * @see https://developers.google.com/identity/protocols/oauth2/web-server#incrementalAuth
	 */
	includeGrantedScopes?: boolean | undefined;
}

const GOOGLE_ID_TOKEN_MAX_AGE = "1h";
const GOOGLE_ID_TOKEN_ALGORITHM = "RS256";
type GoogleIdTokenAlgorithm = typeof GOOGLE_ID_TOKEN_ALGORITHM;
const GOOGLE_ID_TOKEN_ALGORITHMS: GoogleIdTokenAlgorithm[] = [
	GOOGLE_ID_TOKEN_ALGORITHM,
];

function isGoogleIdTokenAlgorithm(
	algorithm: unknown,
): algorithm is GoogleIdTokenAlgorithm {
	return GOOGLE_ID_TOKEN_ALGORITHMS.includes(
		algorithm as GoogleIdTokenAlgorithm,
	);
}

export interface VerifyGoogleIdTokenOptions {
	token: string;
	audience: string | string[];
	nonce?: string | undefined;
}

/**
 * Verifies a Google ID token against Google's issuer, audience, signature,
 * expiry, and maximum token age.
 */
export const verifyGoogleIdToken = async ({
	token,
	audience,
	nonce,
}: VerifyGoogleIdTokenOptions): Promise<JWTPayload | null> => {
	try {
		const { kid, alg } = decodeProtectedHeader(token);
		if (!isGoogleIdTokenAlgorithm(alg)) return null;

		const publicKeys = await getGooglePublicKeys(kid);
		for (const publicKey of publicKeys) {
			try {
				const { payload: jwtClaims } = await jwtVerify(token, publicKey, {
					algorithms: GOOGLE_ID_TOKEN_ALGORITHMS,
					issuer: ["https://accounts.google.com", "accounts.google.com"],
					audience,
					maxTokenAge: GOOGLE_ID_TOKEN_MAX_AGE,
				});

				if (nonce && jwtClaims.nonce !== nonce) {
					return null;
				}

				return jwtClaims;
			} catch {
				continue;
			}
		}

		return null;
	} catch {
		return null;
	}
};

/**
 * Checks whether Google's verified `hd` claim satisfies the configured hosted
 * domain restriction. `hd: "*"` accepts any Google Workspace hosted domain.
 */
export const isGoogleHostedDomainAllowed = (
	configuredHostedDomain: string | undefined,
	tokenHostedDomain: unknown,
) => {
	if (!configuredHostedDomain) return true;
	if (typeof tokenHostedDomain !== "string" || !tokenHostedDomain) {
		return false;
	}
	if (configuredHostedDomain === "*") return true;
	return tokenHostedDomain === configuredHostedDomain;
};

export const google = (options: GoogleOptions) => {
	return {
		id: "google",
		name: "Google",
		accountSubject: ({ profile }) => profile.sub,
		async createAuthorizationURL({
			state,
			scopes,
			codeVerifier,
			redirectURI,
			loginHint,
			display,
			additionalParams,
		}) {
			if (!getPrimaryClientId(options.clientId) || !options.clientSecret) {
				logger.error(
					"Client Id and Client Secret is required for Google. Make sure to provide them in the options.",
				);
				throw new BetterAuthError("CLIENT_ID_AND_SECRET_REQUIRED");
			}
			if (!codeVerifier) {
				throw new BetterAuthError("codeVerifier is required for Google");
			}
			const _scopes = options.disableDefaultScope
				? []
				: ["email", "profile", "openid"];
			if (options.scope) _scopes.push(...options.scope);
			if (scopes) _scopes.push(...scopes);
			const url = await createAuthorizationURL({
				id: "google",
				options,
				authorizationEndpoint: "https://accounts.google.com/o/oauth2/v2/auth",
				scopes: _scopes,
				state,
				codeVerifier,
				redirectURI,
				prompt: options.prompt,
				accessType: options.accessType,
				display: display || options.display,
				loginHint,
				hd: options.hd,
				additionalParams: {
					...(options.includeGrantedScopes === false
						? {}
						: { include_granted_scopes: "true" }),
					...(additionalParams ?? {}),
				},
			});
			return url;
		},
		validateAuthorizationCode: async ({ code, codeVerifier, redirectURI }) => {
			return validateAuthorizationCode({
				code,
				codeVerifier,
				redirectURI,
				options,
				tokenEndpoint: "https://oauth2.googleapis.com/token",
			});
		},
		refreshAccessToken: options.refreshAccessToken
			? options.refreshAccessToken
			: async (refreshToken) => {
					return refreshAccessToken({
						refreshToken,
						options: {
							clientId: options.clientId,
							clientKey: options.clientKey,
							clientSecret: options.clientSecret,
						},
						tokenEndpoint: "https://oauth2.googleapis.com/token",
					});
				},
		idToken: {
			// https://developers.google.com/identity/sign-in/web/backend-auth#verify-the-integrity-of-the-id-token
			jwks: (header) => getGooglePublicKey(header.kid!),
			issuer: ["https://accounts.google.com", "accounts.google.com"],
			audience: options.clientId,
			maxTokenAge: GOOGLE_ID_TOKEN_MAX_AGE,
			// Google's `hd` authorization parameter is only a UI hint and can be
			// removed or changed by the user. When a hosted domain is configured,
			// the `hd` claim in the verified id token is the authoritative value
			// and must satisfy the configured restriction, otherwise accounts
			// outside the workspace domain would be accepted on the id_token path.
			verifyClaims: options.hd
				? (claims) => isGoogleHostedDomainAllowed(options.hd, claims.hd)
				: undefined,
		},
		async getUserInfo(token) {
			if (options.getUserInfo) {
				return options.getUserInfo(token);
			}
			if (!token.idToken) {
				return null;
			}
			const user = decodeJwt(token.idToken) as GoogleProfile;
			// Enforce the configured hosted domain on the callback profile path.
			// The authorization-time `hd` value is only a UI hint; the verified
			// token/profile claim is the authoritative Workspace signal.
			if (!isGoogleHostedDomainAllowed(options.hd, user.hd)) {
				logger.error(
					`Google sign-in rejected: id token hosted domain (hd) "${
						user.hd ?? "<missing>"
					}" does not satisfy the configured "hd" option "${options.hd}".`,
				);
				return null;
			}
			const userMap = await options.mapProfileToUser?.(user);
			return {
				user: {
					name: user.name,
					email: user.email,
					image: user.picture,
					emailVerified: user.email_verified,
					...userMap,
				},
				data: user,
			};
		},
		options,
	} satisfies OAuthProvider<GoogleProfile>;
};

export const getGooglePublicKey = async (kid: string) => {
	const [publicKey] = await getGooglePublicKeys(kid);
	if (!publicKey) {
		throw new Error(`JWK with kid ${kid} not found`);
	}
	return publicKey;
};

const getGooglePublicKeys = async (kid?: string) => {
	const { data } = await betterFetch<{
		keys: Array<{
			kid: string;
			alg?: string;
			kty: string;
			use: string;
			n: string;
			e: string;
		}>;
	}>("https://www.googleapis.com/oauth2/v3/certs");

	if (!data?.keys) {
		throw new APIError("BAD_REQUEST", {
			message: "Keys not found",
		});
	}

	const jwks = kid ? data.keys.filter((key) => key.kid === kid) : data.keys;
	if (!jwks.length) {
		throw new Error(`JWK with kid ${kid} not found`);
	}

	return Promise.all(
		jwks.map((jwk) => importJWK(jwk, GOOGLE_ID_TOKEN_ALGORITHM)),
	);
};
