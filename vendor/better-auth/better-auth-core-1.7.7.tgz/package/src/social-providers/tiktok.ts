import { betterFetch } from "@better-fetch/fetch";
import type {
	OAuthProvider,
	ProviderOptions,
	TokenEndpointAuth,
} from "../oauth2";
import {
	RESERVED_AUTHORIZATION_PARAMS_SET,
	refreshAccessToken,
	validateAuthorizationCode,
} from "../oauth2";
import { createPlaceholderEmail } from "../utils/email";

/**
 * [More info](https://developers.tiktok.com/doc/tiktok-api-v2-get-user-info/)
 */
export interface TiktokProfile extends Record<string, any> {
	data: {
		user: {
			/**
			 * The unique identification of the user in the current application.Open id
			 * for the client.
			 *
			 * To return this field, add `fields=open_id` in the user profile request's query parameter.
			 */
			open_id: string;
			/**
			 * The unique identification of the user across different apps for the same developer.
			 * For example, if a partner has X number of clients,
			 * it will get X number of open_id for the same TikTok user,
			 * but one persistent union_id for the particular user.
			 *
			 * To return this field, add `fields=union_id` in the user profile request's query parameter.
			 */
			union_id?: string | undefined;
			/**
			 * User's profile image.
			 *
			 * To return this field, add `fields=avatar_url` in the user profile request's query parameter.
			 */
			avatar_url?: string | undefined;
			/**
			 * User`s profile image in 100x100 size.
			 *
			 * To return this field, add `fields=avatar_url_100` in the user profile request's query parameter.
			 */
			avatar_url_100?: string | undefined;
			/**
			 * User's profile image with higher resolution
			 *
			 * To return this field, add `fields=avatar_url_100` in the user profile request's query parameter.
			 */
			avatar_large_url: string;
			/**
			 * User's profile name
			 *
			 * To return this field, add `fields=display_name` in the user profile request's query parameter.
			 */
			display_name: string;
			/**
			 * User's username.
			 *
			 * To return this field, add `fields=username` in the user profile request's query parameter.
			 */
			username: string;
			/** @note Email is currently unsupported by TikTok  */
			email?: string | undefined;
			/**
			 * User's bio description if there is a valid one.
			 *
			 * To return this field, add `fields=bio_description` in the user profile request's query parameter.
			 */
			bio_description?: string | undefined;
			/**
			 * The link to user's TikTok profile page.
			 *
			 * To return this field, add `fields=profile_deep_link` in the user profile request's query parameter.
			 */
			profile_deep_link?: string | undefined;
			/**
			 * Whether TikTok has provided a verified badge to the account after confirming
			 * that it belongs to the user it represents.
			 *
			 * To return this field, add `fields=is_verified` in the user profile request's query parameter.
			 */
			is_verified?: boolean | undefined;
			/**
			 * User's followers count.
			 *
			 * To return this field, add `fields=follower_count` in the user profile request's query parameter.
			 */
			follower_count?: number | undefined;
			/**
			 * The number of accounts that the user is following.
			 *
			 * To return this field, add `fields=following_count` in the user profile request's query parameter.
			 */
			following_count?: number | undefined;
			/**
			 * The total number of likes received by the user across all of their videos.
			 *
			 * To return this field, add `fields=likes_count` in the user profile request's query parameter.
			 */
			likes_count?: number | undefined;
			/**
			 * The total number of publicly posted videos by the user.
			 *
			 * To return this field, add `fields=video_count` in the user profile request's query parameter.
			 */
			video_count?: number | undefined;
		};
	};
	error?:
		| {
				/**
				 * The error category in string.
				 */
				code?: string;
				/**
				 * The error message in string.
				 */
				message?: string;
				/**
				 * The error message in string.
				 */
				log_id?: string;
		  }
		| undefined;
}

export interface TiktokOptions extends ProviderOptions<TiktokProfile> {
	// Client ID is not used in TikTok, we delete it from the options
	clientId?: never | undefined;
	clientSecret: string;
	clientKey: string;
}

export const tiktok = (options: TiktokOptions) => {
	const tokenEndpoint = "https://open.tiktokapis.com/v2/oauth/token/";
	const tokenEndpointAuth = {
		method: "custom",
		customizeRequest({ body }) {
			body.set("client_key", options.clientKey);
			body.set("client_secret", options.clientSecret);
		},
	} satisfies TokenEndpointAuth;
	return {
		id: "tiktok",
		name: "TikTok",
		accountSubject: ({ profile }) => profile.data.user.open_id,
		createAuthorizationURL({ state, scopes, redirectURI, additionalParams }) {
			const _scopes = options.disableDefaultScope ? [] : ["user.info.profile"];
			if (options.scope) _scopes.push(...options.scope);
			if (scopes) _scopes.push(...scopes);
			// TikTok uses `client_key` instead of the standard `client_id`, so the
			// shared createAuthorizationURL helper cannot be used directly.
			const url = new URL("https://www.tiktok.com/v2/auth/authorize");
			url.searchParams.set("scope", _scopes.join(","));
			url.searchParams.set("response_type", "code");
			url.searchParams.set("client_key", options.clientKey);
			url.searchParams.set("redirect_uri", options.redirectURI || redirectURI);
			url.searchParams.set("state", state);
			if (additionalParams) {
				for (const [key, value] of Object.entries(additionalParams)) {
					if (RESERVED_AUTHORIZATION_PARAMS_SET.has(key)) continue;
					if (key === "client_key") continue;
					url.searchParams.set(key, value);
				}
			}
			return url;
		},

		validateAuthorizationCode: async ({ code, codeVerifier, redirectURI }) => {
			return validateAuthorizationCode({
				code,
				codeVerifier,
				redirectURI: options.redirectURI || redirectURI,
				options: {},
				tokenEndpoint,
				tokenEndpointAuth,
			});
		},
		refreshAccessToken: options.refreshAccessToken
			? options.refreshAccessToken
			: async (refreshToken) => {
					return refreshAccessToken({
						refreshToken,
						options: {},
						tokenEndpoint,
						tokenEndpointAuth,
					});
				},
		async getUserInfo(token) {
			if (options.getUserInfo) {
				return options.getUserInfo(token);
			}

			const fields = [
				"open_id",
				"avatar_large_url",
				"display_name",
				"username",
			];
			const { data: profile, error } = await betterFetch<TiktokProfile>(
				`https://open.tiktokapis.com/v2/user/info/?fields=${fields.join(",")}`,
				{
					headers: {
						authorization: `Bearer ${token.accessToken}`,
					},
				},
			);

			if (error) {
				return null;
			}

			return {
				user: {
					email:
						profile.data.user.email ||
						createPlaceholderEmail({
							identifier: profile.data.user.open_id,
							namespace: "tiktok",
						}),
					name:
						profile.data.user.display_name || profile.data.user.username || "",
					image: profile.data.user.avatar_large_url,
					emailVerified: false,
				},
				data: profile,
			};
		},
		options,
	} satisfies OAuthProvider<TiktokProfile, TiktokOptions>;
};
