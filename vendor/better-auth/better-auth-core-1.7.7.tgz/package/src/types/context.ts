import type { CookieOptions, EndpointContext } from "better-call";
import type {
	Account,
	BetterAuthDBSchema,
	ModelNames,
	SecondaryStorage,
	Session,
	User,
	Verification,
} from "../db";
import type { DBAdapter, Where } from "../db/adapter";
import type { AccountKey } from "../db/schema/account";
import type { SchemaCheck } from "../db/schema-check";
import type { createLogger } from "../env";
import type { OAuthProvider } from "../oauth2";
import type {
	BetterAuthCookie,
	BetterAuthCookies,
	CookieCachePayload,
} from "./cookie";
import type { Awaitable, LiteralString } from "./helper";
import type {
	BetterAuthOptions,
	BetterAuthRateLimitOptions,
	UserProvisioningSource,
} from "./init-options";
import type { BetterAuthPlugin } from "./plugin";
import type { SecretConfig } from "./secret";

/**
 * @internal
 */
type InferPluginID<O extends BetterAuthOptions> =
	O["plugins"] extends Array<infer P>
		? P extends BetterAuthPlugin
			? P["id"]
			: never
		: never;

/**
 * @internal
 */
type InferPluginOptions<
	O extends BetterAuthOptions,
	ID extends BetterAuthPluginRegistryIdentifier | LiteralString,
> =
	O["plugins"] extends Array<infer P>
		? P extends BetterAuthPlugin
			? P["id"] extends ID
				? P extends { options: infer O }
					? O
					: never
				: never
			: never
		: never;

/**
 * Mutators are defined in each plugin
 *
 * @example
 * ```ts
 * interface MyPluginOptions {
 *   useFeature: boolean
 * }
 *
 * const createMyPlugin = <Options extends MyPluginOptions>(options?: Options) => ({
 *   id: 'my-plugin',
 *   version: '1.0.0',
 *   options,
 * } satisfies BetterAuthPlugin);
 *
 * declare module "@better-auth/core" {
 *  interface BetterAuthPluginRegistry<AuthOptions, Options> {
 *    'my-plugin': {
 *      creator: Options extends MyPluginOptions ? typeof createMyPlugin<Options>: typeof createMyPlugin
 *    }
 *  }
 * }
 * ```
 */
// biome-ignore lint/correctness/noUnusedVariables: Auth and Context is used in the declaration merging
export interface BetterAuthPluginRegistry<AuthOptions, Options> {}
export type BetterAuthPluginRegistryIdentifier = keyof BetterAuthPluginRegistry<
	unknown,
	unknown
>;

export type GenericEndpointContext<
	Options extends BetterAuthOptions = BetterAuthOptions,
> = EndpointContext<string, any> & {
	context: AuthContext<Options>;
};

/**
 * Signs and verifies session cookie-cache values.
 */
export type CookieCacheSigner = {
	sign: (
		ctx: GenericEndpointContext,
		payload: CookieCachePayload,
		expiresIn: number,
	) => Promise<string>;
	verify: (
		ctx: GenericEndpointContext,
		token: string,
	) => Promise<{
		payload: CookieCachePayload;
		expiresAt: number;
	} | null>;
};

export interface InternalAdapter<
	_Options extends BetterAuthOptions = BetterAuthOptions,
> {
	createOAuthUser(
		user: Omit<User, "id" | "createdAt" | "updatedAt">,
		account: Omit<Account, "userId" | "id" | "createdAt" | "updatedAt"> &
			Partial<Account>,
	): Promise<{ user: User; account: Account }>;

	createUser<T extends Record<string, any>>(
		user: Omit<User, "id" | "createdAt" | "updatedAt" | "emailVerified"> &
			Partial<User> &
			Record<string, any>,
		/**
		 * Provisioning source. The creation seam adds `action: "create-user"` and
		 * runs the `user.validateUserInfo` gate.
		 */
		source: UserProvisioningSource,
	): Promise<T & User>;

	createAccount<T extends Record<string, any>>(
		account: Omit<Account, "id" | "createdAt" | "updatedAt"> &
			Partial<Account> &
			T,
	): Promise<T & Account>;

	listSessions(
		userId: string,
		options?: { onlyActiveSessions?: boolean | undefined } | undefined,
	): Promise<Session[]>;

	listUsers(
		limit?: number | undefined,
		offset?: number | undefined,
		sortBy?: { field: string; direction: "asc" | "desc" } | undefined,
		where?: Where[] | undefined,
	): Promise<User[]>;

	countTotalUsers(where?: Where[] | undefined): Promise<number>;

	deleteUser(userId: string): Promise<void>;

	createSession(
		userId: string,
		dontRememberMe?: boolean | undefined,
		override?: (Partial<Session> & Record<string, any>) | undefined,
		overrideAll?: boolean | undefined,
		storageOptions?:
			| { deferSecondaryStorageWrites?: boolean | undefined }
			| undefined,
	): Promise<Session>;

	findSession(token: string): Promise<{
		session: Session & Record<string, any>;
		user: User & Record<string, any>;
	} | null>;

	findSessions(
		sessionTokens: string[],
		options?:
			| {
					onlyActiveSessions?: boolean | undefined;
			  }
			| undefined,
	): Promise<{ session: Session; user: User }[]>;

	updateSession(
		sessionToken: string,
		session: Partial<Session> & Record<string, any>,
	): Promise<Session | null>;

	deleteSession(token: string): Promise<void>;

	deleteAccounts(userId: string): Promise<void>;

	/**
	 * Delete an account by its primary key.
	 *
	 * @param id - The account row's primary key, not its provider account ID.
	 */
	deleteAccount(id: string): Promise<void>;

	/**
	 * Delete every session belonging to a user.
	 */
	deleteUserSessions(userId: string): Promise<void>;

	/**
	 * Delete sessions by their session tokens.
	 */
	deleteSessions(sessionTokens: string[]): Promise<void>;

	findAccountOwnerByKey(accountKey: AccountKey): Promise<
		| {
				kind: "owned";
				user: User;
				account: Account;
		  }
		| {
				kind: "orphaned";
				account: Account;
		  }
		| null
	>;

	findUserByEmail(
		email: string,
		options?: { includeAccounts: boolean } | undefined,
	): Promise<{ user: User; accounts: Account[] } | null>;

	findUserById(userId: string): Promise<User | null>;

	linkAccount(
		account: Omit<Account, "id" | "createdAt" | "updatedAt"> & Partial<Account>,
	): Promise<Account>;

	// Record<string, any> is to take into account additional fields or plugin-added fields
	updateUser<T extends Record<string, any>>(
		userId: string,
		data: Partial<User> & Record<string, any>,
	): Promise<User & T>;

	updateUserByEmail<T extends Record<string, any>>(
		email: string,
		data: Partial<User & Record<string, any>>,
	): Promise<User & T>;

	updatePassword(userId: string, password: string): Promise<void>;

	findAccounts(userId: string): Promise<Account[]>;

	/** Find the credential account whose stable local subject is the user ID. */
	findCredentialAccount(userId: string): Promise<Account | null>;

	findAccountByKey(accountKey: AccountKey): Promise<Account | null>;

	findAccountByUserId(userId: string): Promise<Account[]>;

	updateAccount(id: string, data: Partial<Account>): Promise<Account>;

	createVerificationValue(
		data: Omit<Verification, "createdAt" | "id" | "updatedAt"> &
			Partial<Verification>,
	): Promise<Verification>;

	findVerificationValue(identifier: string): Promise<Verification | null>;

	deleteVerificationByIdentifier(identifier: string): Promise<void>;

	/**
	 * Atomically consume a single-use verification row by `identifier` and
	 * return it. Only the first concurrent caller receives the latest row;
	 * subsequent callers receive `null`. Consuming one row invalidates the
	 * whole identifier so stale rows cannot be replayed. Rows past their
	 * `expiresAt` are treated as already invalid: the row is deleted but
	 * `null` is returned, so callers do not need to gate on `expiresAt`
	 * themselves. Callers MUST gate any state change (issue session, mint
	 * token, change password) on a non-null result.
	 *
	 * Replaces the racy `findVerificationValue` + `deleteVerificationByIdentifier`
	 * pair at single-use credential consumption sites.
	 */
	consumeVerificationValue(identifier: string): Promise<Verification | null>;

	/**
	 * First-writer-wins create keyed by a deterministic primary key derived from
	 * `identifier`. Returns `true` when this caller created the row and `false`
	 * when a row for the same identifier already existed.
	 *
	 * The dual of `consumeVerificationValue`: reserve races to create a marker
	 * exactly once, where consume races to delete one exactly once. Use it for
	 * replay tombstones (a SAML assertion id, a JWT `jti`) where the first caller
	 * wins. The database path is atomic via the primary key. Secondary-storage-only
	 * verification is not supported for reservation and runtime implementations
	 * should fail closed unless verification is backed by the database.
	 */
	reserveVerificationValue(data: {
		identifier: string;
		value: string;
		expiresAt: Date;
	}): Promise<boolean>;

	updateVerificationByIdentifier(
		identifier: string,
		data: Partial<Verification>,
	): Promise<Verification>;

	refreshUserSessions(user: User): Promise<void>;
}

type CreateCookieGetterFn = (
	cookieName: string,
	overrideAttributes?: Partial<CookieOptions> | undefined,
) => BetterAuthCookie;

type CheckPasswordFn<Options extends BetterAuthOptions = BetterAuthOptions> = (
	userId: string,
	ctx: GenericEndpointContext<Options>,
) => Promise<boolean>;

export type PluginContext<Options extends BetterAuthOptions> = {
	getPlugin: <
		ID extends BetterAuthPluginRegistryIdentifier | LiteralString,
		PluginOptions extends InferPluginOptions<Options, ID>,
	>(
		pluginId: ID,
	) =>
		| (ID extends BetterAuthPluginRegistryIdentifier
				? BetterAuthPluginRegistry<Options, PluginOptions>[ID] extends {
						creator: infer C;
					}
					? C extends (...args: any[]) => infer R
						? R
						: never
					: never
				: BetterAuthPlugin)
		| null;
	/**
	 * Checks if a plugin is enabled by its ID.
	 *
	 * @param pluginId - The ID of the plugin to check
	 * @returns `true` if the plugin is enabled, `false` otherwise
	 *
	 * @example
	 * ```ts
	 * if (ctx.context.hasPlugin("organization")) {
	 *   // organization plugin is enabled
	 * }
	 * ```
	 */
	hasPlugin: <ID extends BetterAuthPluginRegistryIdentifier | LiteralString>(
		pluginId: ID,
	) => ID extends InferPluginID<Options> ? true : boolean;
};

export type InfoContext = {
	appName: string;
	baseURL: string;
	version: string;
};

export type AuthContext<Options extends BetterAuthOptions = BetterAuthOptions> =
	PluginContext<Options> &
		InfoContext & {
			options: Options;
			trustedOrigins: string[];
			/**
			 * Resolved list of trusted providers for account linking.
			 * Populated from "account.accountLinking.trustedProviders" (supports static array or async function).
			 */
			trustedProviders: string[];
			/**
			 * Verifies whether url is a trusted origin according to the "trustedOrigins" configuration
			 * @param url The url to verify against the "trustedOrigins" configuration
			 * @param settings Specify supported pattern matching settings
			 * @returns {boolean} true if the URL matches the origin pattern, false otherwise.
			 */
			isTrustedOrigin: (
				url: string,
				settings?: { allowRelativePaths: boolean },
			) => boolean;
			oauthConfig: {
				/**
				 * This is dangerous and should only be used in dev or staging environments.
				 */
				skipStateCookieCheck?: boolean | undefined;
				/**
				 * Strategy for storing OAuth state
				 *
				 * - "cookie": Store state in an encrypted cookie (stateless)
				 * - "database": Store state in the database
				 *
				 * @default "database" when `database` or `secondaryStorage` is configured, "cookie" otherwise
				 */
				storeStateStrategy: "database" | "cookie";
			};
			/**
			 * New session that will be set after the request
			 * meaning: there is a `set-cookie` header that will set
			 * the session cookie. This is the fetched session. And it's set
			 * by `setNewSession` method.
			 */
			newSession: {
				session: Session & Record<string, any>;
				user: User & Record<string, any>;
			} | null;
			session: {
				session: Session & Record<string, any>;
				user: User & Record<string, any>;
			} | null;
			setNewSession: (
				session: {
					session: Session & Record<string, any>;
					user: User & Record<string, any>;
				} | null,
			) => void;
			socialProviders: OAuthProvider[];
			authCookies: BetterAuthCookies;
			logger: ReturnType<typeof createLogger>;
			rateLimit: {
				enabled: boolean;
				window: number;
				max: number;
				storage: "memory" | "database" | "secondary-storage";
			} & Omit<
				BetterAuthRateLimitOptions,
				"enabled" | "window" | "max" | "storage"
			>;
			adapter: DBAdapter<Options>;
			/**
			 * Confirms the database can hold what this configuration writes.
			 *
			 * Shared by initialization and requests for this adapter instance;
			 * returns nothing once the schema is known to be clean.
			 * Context construction does not await the verdict, so migration
			 * tooling can still use a context whose schema needs repair.
			 * Absent when the check is disabled or the adapter registers none.
			 */
			checkSchema?: SchemaCheck | undefined;
			/**
			 * Available for an explicit check even when runtime validation is disabled.
			 */
			explicitSchemaCheck?: SchemaCheck | undefined;
			internalAdapter: InternalAdapter<Options>;
			createAuthCookie: CreateCookieGetterFn;
			secret: string;
			secretConfig: string | SecretConfig;
			sessionConfig: {
				updateAge: number;
				expiresIn: number;
				freshAge: number;
				cookieCacheSigner?: CookieCacheSigner | undefined;
				cookieRefreshCache:
					| false
					| {
							enabled: true;
							updateAge: number;
					  };
			};
			generateId: (options: {
				model: ModelNames;
				size?: number | undefined;
			}) => string | false;
			secondaryStorage: SecondaryStorage | undefined;
			password: {
				hash: (password: string) => Promise<string>;
				verify: (data: { password: string; hash: string }) => Promise<boolean>;
				config: {
					minPasswordLength: number;
					maxPasswordLength: number;
				};
				checkPassword: CheckPasswordFn<Options>;
			};
			tables: BetterAuthDBSchema;
			runMigrations: () => Promise<void>;
			publishTelemetry: (event: {
				type: string;
				anonymousId?: string | undefined;
				payload: Record<string, any>;
			}) => Promise<void>;
			/**
			 * Skip origin check for requests.
			 *
			 * - `true`: Skip for ALL requests (DANGEROUS - disables CSRF protection)
			 * - `string[]`: Skip only for specific paths (e.g., SAML callbacks)
			 * - `false`: Enable origin check (default)
			 *
			 * Paths support prefix matching (e.g., "/sso/saml2/callback" matches
			 * "/sso/saml2/callback/provider-name").
			 *
			 * @default false (true in test environments)
			 */
			skipOriginCheck: boolean | string[];
			/**
			 * This skips the CSRF check for all requests.
			 *
			 * This is inferred from the `options.advanced?.
			 * disableCSRFCheck` option.
			 *
			 * @default false
			 */
			skipCSRFCheck: boolean;
			/**
			 * Background task handler for deferred operations.
			 *
			 * This is inferred from the `options.advanced?.backgroundTasks?.handler` option.
			 * Defaults to a no-op that just runs the promise.
			 */
			runInBackground: (promise: Promise<unknown>) => void;
			/**
			 * Runs a task in the background if `runInBackground` is configured,
			 * otherwise awaits the task directly.
			 *
			 * This is useful for operations like sending emails where we want
			 * to avoid blocking the response when possible (for timing attack
			 * mitigation), but still ensure the operation completes.
			 */
			runInBackgroundOrAwait: (
				promise: Promise<unknown> | void,
			) => Awaitable<unknown>;
		};
